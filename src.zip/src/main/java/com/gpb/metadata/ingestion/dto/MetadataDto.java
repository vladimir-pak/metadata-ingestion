package com.gpb.metadata.ingestion.dto;

public interface MetadataDto {

}
