package com.gpb.metadata.ingestion.service;

import com.gpb.metadata.ingestion.cache.DatabaseCacheComparisonResult;

public interface MetadataCacheService {
    public DatabaseCacheComparisonResult synchronizeWithDatabase(String serviceName);
}
