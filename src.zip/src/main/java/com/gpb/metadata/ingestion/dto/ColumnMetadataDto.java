package com.gpb.metadata.ingestion.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ColumnMetadataDto {
    private String name;
    private String dtype;
    private String dataLength;
    private String description;
}
