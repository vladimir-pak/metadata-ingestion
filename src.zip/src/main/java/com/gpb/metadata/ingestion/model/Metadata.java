package com.gpb.metadata.ingestion.model;

public interface Metadata {
    String getName();
    String getFqn();
    String getServiceName();
    String getParentFqn();
}
