package com.gpb.metadata.ingestion.cache;

import java.util.HashMap;
import java.util.Map;

import com.gpb.metadata.ingestion.model.EntityId;
import com.gpb.metadata.ingestion.model.SchemaMetadata;

import lombok.Data;

@Data
public class SchemaCacheComparisonResult {
    private Map<EntityId, SchemaMetadata> newRecords = new HashMap<>();
    private Map<EntityId, SchemaMetadata> modifiedRecords = new HashMap<>();
    private Map<EntityId, SchemaMetadata> deletedRecords = new HashMap<>();
    
    public void addNewRecord(EntityId id, SchemaMetadata metadata) {
        newRecords.put(id, metadata);
    }
    
    public void addModifiedRecord(EntityId id, SchemaMetadata metadata) {
        modifiedRecords.put(id, metadata);
    }
    
    public void addDeletedRecord(EntityId id, SchemaMetadata metadata) {
        deletedRecords.put(id, metadata);
    }
    
    public boolean hasChanges() {
        return !newRecords.isEmpty() || !modifiedRecords.isEmpty() || !deletedRecords.isEmpty();
    }
}
