package com.gpb.metadata.ingestion.service.impl;

import com.gpb.metadata.ingestion.cache.TableCacheComparisonResult;
import com.gpb.metadata.ingestion.enums.Entity;
import com.gpb.metadata.ingestion.model.EntityId;
import com.gpb.metadata.ingestion.model.TableMetadata;
import com.gpb.metadata.ingestion.repository.TableMetadataCacheRepository;

import lombok.RequiredArgsConstructor;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.query.ScanQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class TableMetadataCacheServiceImpl {

    @Qualifier("igniteInstance")
    private final Ignite ignite;
    
    private final TableMetadataCacheRepository tableRepository;
    
    private final Map<String, IgniteCache<EntityId, TableMetadata>> runtimeCaches = new ConcurrentHashMap<>();
    private final String TEMP_CACHE_PREFIX = String.format("temp_%s_" , Entity.TABLE.name());
    private final String CACHE_NAME = String.format("runtime_%s_" , Entity.TABLE.name());
    
    /**
     * Получить или создать runtime кэш для serviceName
     */
    public IgniteCache<EntityId, TableMetadata> getOrCreateRuntimeCache(String serviceName) {
        return runtimeCaches.computeIfAbsent(serviceName, key -> {
            String cacheName = CACHE_NAME + serviceName;
            
            CacheConfiguration<EntityId, TableMetadata> cacheCfg = new CacheConfiguration<>();
            cacheCfg.setName(cacheName);
            cacheCfg.setCacheMode(CacheMode.REPLICATED); // Все данные на всех узлах
            cacheCfg.setIndexedTypes(EntityId.class, TableMetadata.class);
            
            return ignite.getOrCreateCache(cacheCfg);
        });
    }
    
    /**
     * Создать временный кэш из данных БД
     */
    public IgniteCache<EntityId, TableMetadata> createTempCacheFromDatabase(String serviceName) {
        String tempCacheName = TEMP_CACHE_PREFIX + serviceName + "_" + System.currentTimeMillis();
        
        CacheConfiguration<EntityId, TableMetadata> tempCacheCfg = new CacheConfiguration<>();
        tempCacheCfg.setName(tempCacheName);
        tempCacheCfg.setCacheMode(CacheMode.PARTITIONED); // Распределенный кэш
        tempCacheCfg.setIndexedTypes(EntityId.class, TableMetadata.class);
        
        IgniteCache<EntityId, TableMetadata> tempCache = ignite.getOrCreateCache(tempCacheCfg);
        
        // Загружаем данные из БД
        List<TableMetadata> dbData = tableRepository.findByServiceName(serviceName);
        Map<EntityId, TableMetadata> tempData = dbData.stream()
            // .collect(Collectors.toMap(
            //     metadata -> metadata.getId().getId(),
            //     Function.identity()
            // ));
            .collect(Collectors.toMap(
                TableMetadata::getId, 
                Function.identity()
            ));
        
        tempCache.putAll(tempData);
        return tempCache;
    }
    
    /**
     * Сравнить runtime кэш с временным (из БД) и найти изменения
     */
    public TableCacheComparisonResult compareCaches(String serviceName) {
        IgniteCache<EntityId, TableMetadata> runtimeCache = getOrCreateRuntimeCache(serviceName);
        IgniteCache<EntityId, TableMetadata> tempCache = createTempCacheFromDatabase(serviceName);
        
        try {
            TableCacheComparisonResult result = new TableCacheComparisonResult();
            
            // Находим новые записи (есть в temp, но нет в runtime)
            findNewRecords(runtimeCache, tempCache, result);
            
            // Находим измененные записи (есть в обоих, но hashData отличается)
            findModifiedRecords(runtimeCache, tempCache, result);
            
            // Находим удаленные записи (есть в runtime, но нет в temp)
            findDeletedRecords(runtimeCache, tempCache, result);
            
            return result;
            
        } finally {
            // Всегда удаляем временный кэш
            tempCache.destroy();
        }
    }
    
    /**
     * Обновить runtime кэш на основе временного кэша
     */
    public void updateRuntimeCache(String serviceName, TableCacheComparisonResult changes) {
        IgniteCache<EntityId, TableMetadata> runtimeCache = getOrCreateRuntimeCache(serviceName);
        
        // Удаляем записи, которые были удалены в БД
        if (!changes.getDeletedRecords().isEmpty()) {
            runtimeCache.removeAll(changes.getDeletedRecords().keySet());
        }
        
        // Обновляем/добавляем измененные и новые записи
        Map<EntityId, TableMetadata> recordsToUpdate = new HashMap<>();
        recordsToUpdate.putAll(changes.getNewRecords());
        recordsToUpdate.putAll(changes.getModifiedRecords());
        
        if (!recordsToUpdate.isEmpty()) {
            runtimeCache.putAll(recordsToUpdate);
        }
    }
    
    /**
     * Полная синхронизация: сравнить и обновить
     */
    public TableCacheComparisonResult synchronizeWithDatabase(String serviceName) {
        TableCacheComparisonResult changes = compareCaches(serviceName);
        updateRuntimeCache(serviceName, changes);
        return changes;
    }
    
    private void findNewRecords(IgniteCache<EntityId, TableMetadata> runtimeCache, 
                               IgniteCache<EntityId, TableMetadata> tempCache,
                               TableCacheComparisonResult result) {
        // Получаем все ключи из временного кэша
        Set<EntityId> tempKeys = getAllKeys(tempCache);
        
        // Получаем все ключи из runtime кэша
        Set<EntityId> runtimeKeys = getAllKeys(runtimeCache);
        
        // Новые записи - есть в temp, но нет в runtime
        tempKeys.removeAll(runtimeKeys);
        
        for (EntityId key : tempKeys) {
            TableMetadata tempData = tempCache.get(key);
            if (tempData != null) {
                result.addNewRecord(key, tempData);
            }
        }
    }
    
    private void findModifiedRecords(IgniteCache<EntityId, TableMetadata> runtimeCache,
                                    IgniteCache<EntityId, TableMetadata> tempCache,
                                    TableCacheComparisonResult result) {
        // Общие ключи в обоих кэшах
        Set<EntityId> commonKeys = new HashSet<>(getAllKeys(runtimeCache));
        commonKeys.retainAll(getAllKeys(tempCache));
        
        for (EntityId key : commonKeys) {
            TableMetadata runtimeData = runtimeCache.get(key);
            TableMetadata tempData = tempCache.get(key);
            
            if (runtimeData != null && tempData != null && 
                !Objects.equals(runtimeData.getHashData(), tempData.getHashData())) {
                result.addModifiedRecord(key, tempData);
            }
        }
    }
    
    private void findDeletedRecords(IgniteCache<EntityId, TableMetadata> runtimeCache,
                                   IgniteCache<EntityId, TableMetadata> tempCache,
                                   TableCacheComparisonResult result) {
        // Получаем все ключи из runtime кэша
        Set<EntityId> runtimeKeys = getAllKeys(runtimeCache);
        
        // Получаем все ключи из временного кэша
        Set<EntityId> tempKeys = getAllKeys(tempCache);
        
        // Удаленные записи - есть в runtime, но нет в temp
        runtimeKeys.removeAll(tempKeys);
        
        for (EntityId key : runtimeKeys) {
            TableMetadata runtimeData = runtimeCache.get(key);
            if (runtimeData != null) {
                result.addDeletedRecord(key, runtimeData);
            }
        }
    }
    
    private Set<EntityId> getAllKeys(IgniteCache<EntityId, TableMetadata> cache) {
        Set<EntityId> keys = new HashSet<>();
        cache.query(new ScanQuery<EntityId, TableMetadata>())
            .forEach(entry -> keys.add(entry.getKey()));
        return keys;
    }
    
    /**
     * Удалить runtime кэш для serviceName
     */
    public void destroyRuntimeCache(String serviceName) {
        IgniteCache<EntityId, TableMetadata> cache = runtimeCaches.remove(serviceName);
        if (cache != null) {
            cache.destroy();
        }
    }
    
    /**
     * Получить все runtime кэши
     */
    public Set<String> getAllRuntimeCaches() {
        return new HashSet<>(runtimeCaches.keySet());
    }
}
