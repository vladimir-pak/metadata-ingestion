package com.gpb.metadata.ingestion.service;

public interface MetadataHandlerService {
    public void start(String serviceName);
}
