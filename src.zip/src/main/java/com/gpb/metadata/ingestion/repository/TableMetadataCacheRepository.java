package com.gpb.metadata.ingestion.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gpb.metadata.ingestion.model.TableMetadata;

import java.util.List;

@Repository
public interface TableMetadataCacheRepository extends JpaRepository<TableMetadata, Long> {

    /**
     * Поиск всех записей по serviceName
     */
    List<TableMetadata> findByServiceName(String serviceName);

    /**
     * Удаление всех записей по serviceName
     */
    void deleteByServiceName(String serviceName);
}
