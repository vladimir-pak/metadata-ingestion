package com.gpb.metadata.ingestion.service.impl;

import com.gpb.metadata.ingestion.cache.DatabaseCacheComparisonResult;
import com.gpb.metadata.ingestion.enums.Entity;
import com.gpb.metadata.ingestion.model.DatabaseMetadata;
import com.gpb.metadata.ingestion.model.EntityId;
import com.gpb.metadata.ingestion.repository.DatabaseMetadataCacheRepository;
import com.gpb.metadata.ingestion.service.MetadataCacheService;

import lombok.RequiredArgsConstructor;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.query.ScanQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DatabaseMetadataCacheServiceImpl implements MetadataCacheService {

    @Qualifier("igniteInstance")
    private final Ignite ignite;
    
    private final DatabaseMetadataCacheRepository dbRepository;
    
    private final Map<String, IgniteCache<EntityId, DatabaseMetadata>> runtimeCaches = new ConcurrentHashMap<>();
    private final String TEMP_CACHE_PREFIX = String.format("temp_%s_" , Entity.DATABASE.name());
    private final String CACHE_NAME = String.format("runtime_%s_" , Entity.DATABASE.name());
    
    /**
     * Получить или создать runtime кэш по serviceName
     */
    private IgniteCache<EntityId, DatabaseMetadata> getOrCreateRuntimeCache(String serviceName) {
        return runtimeCaches.computeIfAbsent(serviceName, key -> {
            String cacheName = CACHE_NAME + serviceName;
            
            CacheConfiguration<EntityId, DatabaseMetadata> cacheCfg = new CacheConfiguration<>();
            cacheCfg.setName(cacheName);
            cacheCfg.setCacheMode(CacheMode.REPLICATED); // Все данные на всех узлах
            cacheCfg.setIndexedTypes(EntityId.class, DatabaseMetadata.class);
            
            return ignite.getOrCreateCache(cacheCfg);
        });
    }
    
    /**
     * Создать временный кэш из данных БД
     */
    private IgniteCache<EntityId, DatabaseMetadata> createTempCacheFromDatabase(String serviceName) {
        String tempCacheName = TEMP_CACHE_PREFIX + serviceName + "_" + System.currentTimeMillis();
        
        CacheConfiguration<EntityId, DatabaseMetadata> tempCacheCfg = new CacheConfiguration<>();
        tempCacheCfg.setName(tempCacheName);
        tempCacheCfg.setCacheMode(CacheMode.PARTITIONED); // Распределенный кэш
        tempCacheCfg.setIndexedTypes(EntityId.class, DatabaseMetadata.class);
        
        IgniteCache<EntityId, DatabaseMetadata> tempCache = ignite.getOrCreateCache(tempCacheCfg);
        
        // Загружаем данные из БД
        List<DatabaseMetadata> dbData = dbRepository.findByServiceName(serviceName);
        Map<EntityId, DatabaseMetadata> tempData = dbData.stream()
            // .collect(Collectors.toMap(
            //     metadata -> metadata.getId().getId(),
            //     Function.identity()
            // ));
            .collect(Collectors.toMap(
                DatabaseMetadata::getId,
                Function.identity()
            ));
        
        tempCache.putAll(tempData);
        return tempCache;
    }
    
    /**
     * Сравнить runtime кэш с временным (из БД) и найти изменения
     */
    private DatabaseCacheComparisonResult compareCaches(String serviceName) {
        IgniteCache<EntityId, DatabaseMetadata> runtimeCache = getOrCreateRuntimeCache(serviceName);
        IgniteCache<EntityId, DatabaseMetadata> tempCache = createTempCacheFromDatabase(serviceName);
        
        try {
            DatabaseCacheComparisonResult result = new DatabaseCacheComparisonResult();
            
            // Находим новые записи (есть в temp, но нет в runtime)
            findNewRecords(runtimeCache, tempCache, result);
            
            // Находим измененные записи (есть в обоих, но hashData отличается)
            findModifiedRecords(runtimeCache, tempCache, result);
            
            // Находим удаленные записи (есть в runtime, но нет в temp)
            findDeletedRecords(runtimeCache, tempCache, result);
            
            return result;
            
        } finally {
            // Всегда удаляем временный кэш
            tempCache.destroy();
        }
    }
    
    /**
     * Обновить runtime кэш на основе временного кэша
     */
    private void updateRuntimeCache(String serviceName, DatabaseCacheComparisonResult changes) {
        IgniteCache<EntityId, DatabaseMetadata> runtimeCache = getOrCreateRuntimeCache(serviceName);
        
        // Удаляем записи, которые были удалены в БД
        if (!changes.getDeletedRecords().isEmpty()) {
            runtimeCache.removeAll(changes.getDeletedRecords().keySet());
        }
        
        // Обновляем/добавляем измененные и новые записи
        Map<EntityId, DatabaseMetadata> recordsToUpdate = new HashMap<>();
        recordsToUpdate.putAll(changes.getNewRecords());
        recordsToUpdate.putAll(changes.getModifiedRecords());
        
        if (!recordsToUpdate.isEmpty()) {
            runtimeCache.putAll(recordsToUpdate);
        }
    }
    
    /**
     * Полная синхронизация: сравнить и обновить
     */
    @Override
    public DatabaseCacheComparisonResult synchronizeWithDatabase(String serviceName) {
        DatabaseCacheComparisonResult changes = compareCaches(serviceName);
        updateRuntimeCache(serviceName, changes);
        return changes;
    }
    
    private void findNewRecords(IgniteCache<EntityId, DatabaseMetadata> runtimeCache, 
                               IgniteCache<EntityId, DatabaseMetadata> tempCache,
                               DatabaseCacheComparisonResult result) {
        // Получаем все ключи из временного кэша
        Set<EntityId> tempKeys = getAllKeys(tempCache);
        
        // Получаем все ключи из runtime кэша
        Set<EntityId> runtimeKeys = getAllKeys(runtimeCache);
        
        // Новые записи - есть в temp, но нет в runtime
        tempKeys.removeAll(runtimeKeys);
        
        for (EntityId key : tempKeys) {
            DatabaseMetadata tempData = tempCache.get(key);
            if (tempData != null) {
                result.addNewRecord(key, tempData);
            }
        }
    }
    
    private void findModifiedRecords(IgniteCache<EntityId, DatabaseMetadata> runtimeCache,
                                    IgniteCache<EntityId, DatabaseMetadata> tempCache,
                                    DatabaseCacheComparisonResult result) {
        // Общие ключи в обоих кэшах
        Set<EntityId> commonKeys = new HashSet<>(getAllKeys(runtimeCache));
        commonKeys.retainAll(getAllKeys(tempCache));
        
        for (EntityId key : commonKeys) {
            DatabaseMetadata runtimeData = runtimeCache.get(key);
            DatabaseMetadata tempData = tempCache.get(key);
            
            if (runtimeData != null && tempData != null && 
                !Objects.equals(runtimeData.getHashData(), tempData.getHashData())) {
                result.addModifiedRecord(key, tempData);
            }
        }
    }
    
    private void findDeletedRecords(IgniteCache<EntityId, DatabaseMetadata> runtimeCache,
                                   IgniteCache<EntityId, DatabaseMetadata> tempCache,
                                   DatabaseCacheComparisonResult result) {
        // Получаем все ключи из runtime кэша
        Set<EntityId> runtimeKeys = getAllKeys(runtimeCache);
        
        // Получаем все ключи из временного кэша
        Set<EntityId> tempKeys = getAllKeys(tempCache);
        
        // Удаленные записи - есть в runtime, но нет в temp
        runtimeKeys.removeAll(tempKeys);
        
        for (EntityId key : runtimeKeys) {
            DatabaseMetadata runtimeData = runtimeCache.get(key);
            if (runtimeData != null) {
                result.addDeletedRecord(key, runtimeData);
            }
        }
    }
    
    private Set<EntityId> getAllKeys(IgniteCache<EntityId, DatabaseMetadata> cache) {
        Set<EntityId> keys = new HashSet<>();
        cache.query(new ScanQuery<EntityId, DatabaseMetadata>())
            .forEach(entry -> keys.add(entry.getKey()));
        return keys;
    }
    
    /**
     * Удалить runtime кэш для serviceName
     */
    public void destroyRuntimeCache(String serviceName) {
        IgniteCache<EntityId, DatabaseMetadata> cache = runtimeCaches.remove(serviceName);
        if (cache != null) {
            cache.destroy();
        }
    }
    
    /**
     * Получить все runtime кэши
     */
    public Set<String> getAllRuntimeCaches() {
        return new HashSet<>(runtimeCaches.keySet());
    }
}
