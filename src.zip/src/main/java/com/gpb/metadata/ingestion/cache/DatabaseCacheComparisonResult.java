package com.gpb.metadata.ingestion.cache;

import java.util.HashMap;
import java.util.Map;

import com.gpb.metadata.ingestion.model.DatabaseMetadata;
import com.gpb.metadata.ingestion.model.EntityId;

import lombok.Data;

@Data
public class DatabaseCacheComparisonResult {
    private Map<EntityId, DatabaseMetadata> newRecords = new HashMap<>();
    private Map<EntityId, DatabaseMetadata> modifiedRecords = new HashMap<>();
    private Map<EntityId, DatabaseMetadata> deletedRecords = new HashMap<>();
    
    public void addNewRecord(EntityId id, DatabaseMetadata metadata) {
        newRecords.put(id, metadata);
    }
    
    public void addModifiedRecord(EntityId id, DatabaseMetadata metadata) {
        modifiedRecords.put(id, metadata);
    }
    
    public void addDeletedRecord(EntityId id, DatabaseMetadata metadata) {
        deletedRecords.put(id, metadata);
    }
    
    public boolean hasChanges() {
        return !newRecords.isEmpty() || !modifiedRecords.isEmpty() || !deletedRecords.isEmpty();
    }
}
