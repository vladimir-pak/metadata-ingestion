package com.gpb.metadata.ingestion.service.impl;

import com.gpb.metadata.ingestion.cache.SchemaCacheComparisonResult;
import com.gpb.metadata.ingestion.enums.Entity;
import com.gpb.metadata.ingestion.model.EntityId;
import com.gpb.metadata.ingestion.model.SchemaMetadata;
import com.gpb.metadata.ingestion.repository.SchemaMetadataCacheRepository;

import lombok.RequiredArgsConstructor;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.query.ScanQuery;
import org.apache.ignite.configuration.CacheConfiguration;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SchemaMetadataCacheServiceImpl {

    @Qualifier("igniteInstance")
    private final Ignite ignite;
    
    private final SchemaMetadataCacheRepository schemaRepository;
    
    private final Map<String, IgniteCache<EntityId, SchemaMetadata>> runtimeCaches = new ConcurrentHashMap<>();
    private final String TEMP_CACHE_PREFIX = String.format("temp_%s_" , Entity.SCHEMA.name());
    private final String CACHE_NAME = String.format("runtime_%s_" , Entity.SCHEMA.name());
    
    /**
     * Получить или создать runtime кэш для serviceName
     */
    private IgniteCache<EntityId, SchemaMetadata> getOrCreateRuntimeCache(String serviceName) {
        return runtimeCaches.computeIfAbsent(serviceName, key -> {
            String cacheName = CACHE_NAME + serviceName;
            
            CacheConfiguration<EntityId, SchemaMetadata> cacheCfg = new CacheConfiguration<>();
            cacheCfg.setName(cacheName);
            cacheCfg.setCacheMode(CacheMode.REPLICATED); // Все данные на всех узлах
            cacheCfg.setIndexedTypes(EntityId.class, SchemaMetadata.class);
            
            return ignite.getOrCreateCache(cacheCfg);
        });
    }
    
    /**
     * Создать временный кэш из данных БД
     */
    private IgniteCache<EntityId, SchemaMetadata> createTempCacheFromDatabase(String serviceName) {
        String tempCacheName = TEMP_CACHE_PREFIX + serviceName + "_" + System.currentTimeMillis();
        
        CacheConfiguration<EntityId, SchemaMetadata> tempCacheCfg = new CacheConfiguration<>();
        tempCacheCfg.setName(tempCacheName);
        tempCacheCfg.setCacheMode(CacheMode.PARTITIONED); // Распределенный кэш
        tempCacheCfg.setIndexedTypes(EntityId.class, SchemaMetadata.class);
        
        IgniteCache<EntityId, SchemaMetadata> tempCache = ignite.getOrCreateCache(tempCacheCfg);
        
        // Загружаем данные из БД
        List<SchemaMetadata> dbData = schemaRepository.findByServiceName(serviceName);
        Map<EntityId, SchemaMetadata> tempData = dbData.stream()
            // .collect(Collectors.toMap(
            //     metadata -> metadata.getId().getId(),
            //     Function.identity()
            // ));
            .collect(Collectors.toMap(
                SchemaMetadata::getId,
                Function.identity()
            ));
        
        tempCache.putAll(tempData);
        return tempCache;
    }
    
    /**
     * Сравнить runtime кэш с временным (из БД) и найти изменения
     */
    private SchemaCacheComparisonResult compareCaches(String serviceName) {
        IgniteCache<EntityId, SchemaMetadata> runtimeCache = getOrCreateRuntimeCache(serviceName);
        IgniteCache<EntityId, SchemaMetadata> tempCache = createTempCacheFromDatabase(serviceName);
        
        try {
            SchemaCacheComparisonResult result = new SchemaCacheComparisonResult();
            
            // Находим новые записи (есть в temp, но нет в runtime)
            findNewRecords(runtimeCache, tempCache, result);
            
            // Находим измененные записи (есть в обоих, но hashData отличается)
            findModifiedRecords(runtimeCache, tempCache, result);
            
            // Находим удаленные записи (есть в runtime, но нет в temp)
            findDeletedRecords(runtimeCache, tempCache, result);
            
            return result;
            
        } finally {
            // Всегда удаляем временный кэш
            tempCache.destroy();
        }
    }
    
    /**
     * Обновить runtime кэш на основе временного кэша
     */
    private void updateRuntimeCache(String serviceName, SchemaCacheComparisonResult changes) {
        IgniteCache<EntityId, SchemaMetadata> runtimeCache = getOrCreateRuntimeCache(serviceName);
        
        // Удаляем записи, которые были удалены в БД
        if (!changes.getDeletedRecords().isEmpty()) {
            runtimeCache.removeAll(changes.getDeletedRecords().keySet());
        }
        
        // Обновляем/добавляем измененные и новые записи
        Map<EntityId, SchemaMetadata> recordsToUpdate = new HashMap<>();
        recordsToUpdate.putAll(changes.getNewRecords());
        recordsToUpdate.putAll(changes.getModifiedRecords());
        
        if (!recordsToUpdate.isEmpty()) {
            runtimeCache.putAll(recordsToUpdate);
        }
    }
    
    /**
     * Полная синхронизация: сравнить и обновить
     */
    
    public SchemaCacheComparisonResult synchronizeWithDatabase(String serviceName) {
        SchemaCacheComparisonResult changes = compareCaches(serviceName);
        updateRuntimeCache(serviceName, changes);
        return changes;
    }
    
    private void findNewRecords(IgniteCache<EntityId, SchemaMetadata> runtimeCache, 
                               IgniteCache<EntityId, SchemaMetadata> tempCache,
                               SchemaCacheComparisonResult result) {
        // Получаем все ключи из временного кэша
        Set<EntityId> tempKeys = getAllKeys(tempCache);
        
        // Получаем все ключи из runtime кэша
        Set<EntityId> runtimeKeys = getAllKeys(runtimeCache);
        
        // Новые записи - есть в temp, но нет в runtime
        tempKeys.removeAll(runtimeKeys);
        
        for (EntityId key : tempKeys) {
            SchemaMetadata tempData = tempCache.get(key);
            if (tempData != null) {
                result.addNewRecord(key, tempData);
            }
        }
    }
    
    private void findModifiedRecords(IgniteCache<EntityId, SchemaMetadata> runtimeCache,
                                    IgniteCache<EntityId, SchemaMetadata> tempCache,
                                    SchemaCacheComparisonResult result) {
        // Общие ключи в обоих кэшах
        Set<EntityId> commonKeys = new HashSet<>(getAllKeys(runtimeCache));
        commonKeys.retainAll(getAllKeys(tempCache));
        
        for (EntityId key : commonKeys) {
            SchemaMetadata runtimeData = runtimeCache.get(key);
            SchemaMetadata tempData = tempCache.get(key);
            
            if (runtimeData != null && tempData != null && 
                !Objects.equals(runtimeData.getHashData(), tempData.getHashData())) {
                result.addModifiedRecord(key, tempData);
            }
        }
    }
    
    private void findDeletedRecords(IgniteCache<EntityId, SchemaMetadata> runtimeCache,
                                   IgniteCache<EntityId, SchemaMetadata> tempCache,
                                   SchemaCacheComparisonResult result) {
        // Получаем все ключи из runtime кэша
        Set<EntityId> runtimeKeys = getAllKeys(runtimeCache);
        
        // Получаем все ключи из временного кэша
        Set<EntityId> tempKeys = getAllKeys(tempCache);
        
        // Удаленные записи - есть в runtime, но нет в temp
        runtimeKeys.removeAll(tempKeys);
        
        for (EntityId key : runtimeKeys) {
            SchemaMetadata runtimeData = runtimeCache.get(key);
            if (runtimeData != null) {
                result.addDeletedRecord(key, runtimeData);
            }
        }
    }
    
    private Set<EntityId> getAllKeys(IgniteCache<EntityId, SchemaMetadata> cache) {
        Set<EntityId> keys = new HashSet<>();
        cache.query(new ScanQuery<EntityId, SchemaMetadata>())
            .forEach(entry -> keys.add(entry.getKey()));
        return keys;
    }
    
    /**
     * Удалить runtime кэш для serviceName
     */
    public void destroyRuntimeCache(String serviceName) {
        IgniteCache<EntityId, SchemaMetadata> cache = runtimeCaches.remove(serviceName);
        if (cache != null) {
            cache.destroy();
        }
    }
    
    /**
     * Получить все runtime кэши
     */
    public Set<String> getAllRuntimeCaches() {
        return new HashSet<>(runtimeCaches.keySet());
    }
}
